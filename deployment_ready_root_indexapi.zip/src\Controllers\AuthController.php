<?php

declare(strict_types=1);

namespace App\Controllers;

use PDO;
use App\Models\User;
use App\Helpers\JwtHelper;

class AuthController
{
  private PDO $db;

  public function __construct(PDO $db)
  {
    $this->db = $db;
  }

  public function login(): void
  {
    try {
      $input = self::getJson();
      $identifier = $input['loginInput'] ?? $input['email'] ?? $input['username'] ?? null;
      $password = $input['password'] ?? null;
      if (!$identifier || !$password) {
        self::json(400, ['message' => 'Please provide username/email and password']);
        return;
      }
      $userModel = new User($this->db);
      $user = $userModel->findByUsernameOrEmail((string) $identifier);
      if (!$user || !password_verify((string) $password, (string) ($user->password ?? ''))) {
        self::json(400, ['message' => 'Invalid credentials']);
        return;
      }
      $secret = getenv('JWT_SECRET') ?: 'secret';
      $token = JwtHelper::encode(
        ['id' => $user->user_id, 'username' => $user->username],
        $secret
      );
      $payload = ['user_id' => $user->user_id, 'username' => $user->username, 'email' => $user->email ?? ''];
      if (!empty($user->profile_photo)) $payload['profile_photo'] = $user->profile_photo;
      self::json(200, ['message' => 'Login successful', 'token' => $token, 'user' => $payload]);
    } catch (\Throwable $e) {
      http_response_code(500);
      header('Content-Type: application/json; charset=utf-8');
      echo json_encode([
        'message' => 'Login failed',
        'error' => $e->getMessage(),
        'file' => $e->getFile() . ':' . $e->getLine(),
      ], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    }
  }

  public function register(): void
  {
    $input = self::getJson();
    $username = $input['username'] ?? '';
    $email = $input['email'] ?? '';
    $password = $input['password'] ?? '';
    if (!$username || !$email || !$password) {
      self::json(400, ['message' => 'Please fill in all fields']);
      return;
    }
    if (!$this->isStrongPassword((string) $password)) {
      self::json(400, ['message' => 'Password must be at least 16 characters and include at least one uppercase letter, one lowercase letter, one number, and one special character.']);
      return;
    }
    $userModel = new User($this->db);
    $existing = $userModel->findByUsernameOrEmail($username);
    if ($existing) {
      self::json(400, ['message' => $existing->email === $email ? 'Email is already registered' : 'Username is already taken']);
      return;
    }
    $hash = password_hash($password, PASSWORD_BCRYPT);
    $id = $userModel->create($username, $email, $hash);
    $secret = getenv('JWT_SECRET') ?: 'secret';
    $token = JwtHelper::encode(['id' => $id, 'username' => $username], $secret);
    self::json(201, [
      'message' => 'User created successfully',
      'token' => $token,
      'user' => ['user_id' => $id, 'username' => $username, 'email' => $email],
    ]);
  }


  private static function getJson(): array
  {
    $raw = file_get_contents('php://input');
    $dec = json_decode($raw, true);
    return is_array($dec) ? $dec : [];
  }

  private static function json(int $code, array $data): void
  {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
  }

  private function isStrongPassword(string $password): bool
  {
    if (strlen($password) < 16) {
      return false;
    }

    $hasUppercase = preg_match('/[A-Z]/', $password) === 1;
    $hasLowercase = preg_match('/[a-z]/', $password) === 1;
    $hasNumber = preg_match('/[0-9]/', $password) === 1;
    $hasSpecial = preg_match('/[^A-Za-z0-9]/', $password) === 1;

    return $hasUppercase && $hasLowercase && $hasNumber && $hasSpecial;
  }
}
