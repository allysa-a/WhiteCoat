<?php

declare(strict_types=1);

namespace App\Models;

use PDO;

class User
{
  private PDO $db;

  public function __construct(PDO $db)
  {
    $this->db = $db;
  }

  public function findByUsernameOrEmail(string $identifier): ?object
  {
    $stmt = $this->db->prepare('SELECT user_id, username, email, password FROM users WHERE username = ? OR email = ?');
    $stmt->execute([$identifier, $identifier]);
    $user = $stmt->fetch();
    if (!$user) return null;
    try {
      $stmt2 = $this->db->prepare('SELECT profile_photo FROM users WHERE user_id = ?');
      $stmt2->execute([$user->user_id]);
      $row = $stmt2->fetch();
      if ($row && $row->profile_photo !== null) $user->profile_photo = $row->profile_photo;
    } catch (\Throwable $e) {
    }
    return $user;
  }

  public function findById(int $userId): ?object
  {
    $stmt = $this->db->prepare('SELECT user_id, username, email, password FROM users WHERE user_id = ?');
    $stmt->execute([$userId]);
    return $stmt->fetch() ?: null;
  }

  public function getPrescriptionUrl(int $userId): ?string
  {
    $stmt = $this->db->prepare('SELECT prescription FROM users WHERE user_id = ?');
    $stmt->execute([$userId]);
    $row = $stmt->fetch();
    return $row->prescription ?? null;
  }

  public function getMedicalCertificateUrl(int $userId): ?string
  {
    $stmt = $this->db->prepare('SELECT medical_certificate FROM users WHERE user_id = ?');
    $stmt->execute([$userId]);
    $row = $stmt->fetch();
    return $row->medical_certificate ?? null;
  }

  public function getProfileWithFiles(int $userId): ?object
  {
    try {
      $stmt = $this->db->prepare('SELECT user_id, username, email, profile_photo, prescription, medical_certificate, prescription_file_name, medical_certificate_file_name FROM users WHERE user_id = ?');
      $stmt->execute([$userId]);
      return $stmt->fetch() ?: null;
    } catch (\Throwable $e) {
      if (strpos($e->getMessage(), 'Unknown column') !== false) {
        $stmt = $this->db->prepare('SELECT user_id, username, email FROM users WHERE user_id = ?');
        $stmt->execute([$userId]);
        return $stmt->fetch() ?: null;
      }
      throw $e;
    }
  }

  public function updateProfile(int $userId, string $username, string $email, string $hashedPassword): void
  {
    $stmt = $this->db->prepare('UPDATE users SET username = ?, email = ?, password = ? WHERE user_id = ?');
    $stmt->execute([$username, $email, $hashedPassword, $userId]);
  }

  public function updatePrescription(int $userId, string $url, ?string $fileName = null): void
  {
    try {
      $stmt = $this->db->prepare('UPDATE users SET prescription = ?, prescription_file_name = COALESCE(?, prescription_file_name) WHERE user_id = ?');
      $stmt->execute([$url, $fileName, $userId]);
    } catch (\Throwable $e) {
      if (strpos($e->getMessage(), 'Unknown column') === false) throw $e;
      $stmt = $this->db->prepare('UPDATE users SET prescription = ? WHERE user_id = ?');
      $stmt->execute([$url, $userId]);
    }
  }

  public function updateMedicalCertificate(int $userId, string $url, ?string $fileName = null): void
  {
    try {
      $stmt = $this->db->prepare('UPDATE users SET medical_certificate = ?, medical_certificate_file_name = COALESCE(?, medical_certificate_file_name) WHERE user_id = ?');
      $stmt->execute([$url, $fileName, $userId]);
    } catch (\Throwable $e) {
      if (strpos($e->getMessage(), 'Unknown column') === false) throw $e;
      $stmt = $this->db->prepare('UPDATE users SET medical_certificate = ? WHERE user_id = ?');
      $stmt->execute([$url, $userId]);
    }
  }

  public function updateProfilePhoto(int $userId, string $url): void
  {
    $stmt = $this->db->prepare('UPDATE users SET profile_photo = ? WHERE user_id = ?');
    $stmt->execute([$url, $userId]);
  }

  public function getSignatureUrl(int $userId): ?string
  {
    try {
      $stmt = $this->db->prepare('SELECT e_signature FROM users WHERE user_id = ?');
      $stmt->execute([$userId]);
      $row = $stmt->fetch();
      return $row->e_signature ?? null;
    } catch (\Throwable $e) {
      return null;
    }
  }

  public function updateSignature(int $userId, string $url): void
  {
    $stmt = $this->db->prepare('UPDATE users SET e_signature = ? WHERE user_id = ?');
    $stmt->execute([$url, $userId]);
  }

  public function create(string $username, string $email, string $hashedPassword): int
  {
    $stmt = $this->db->prepare('INSERT INTO users (username, email, password) VALUES (?, ?, ?)');
    $stmt->execute([$username, $email, $hashedPassword]);
    return (int) $this->db->lastInsertId();
  }
}
