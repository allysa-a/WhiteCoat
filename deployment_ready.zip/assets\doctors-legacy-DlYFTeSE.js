System.register([],function(e,t){"use strict";return{execute:function(){e("_","/deployment/assets/deped-DKSAC1QX.png"),e("a","/deployment/assets/doctors-CUqAlnPH.png")}}});
