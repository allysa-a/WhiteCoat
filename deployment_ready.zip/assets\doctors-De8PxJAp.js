const s="/deployment/assets/deped-DKSAC1QX.png",t="/deployment/assets/doctors-CUqAlnPH.png";export{s as _,t as a};
