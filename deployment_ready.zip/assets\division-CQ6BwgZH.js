const s="/deployment/assets/division-CWqrCBC8.png";export{s as _};
