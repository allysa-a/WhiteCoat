(function () {
  let cachedPatients = null;
  let lastUserId = null;
  let lastAutofillName = '';
  let cachedHistoryRows = null;
  let lastHistoryUserId = null;
  let lastHistoryFetchedAt = 0;
  let historyFetchInFlight = null;

  function getFormRoot() {
    return document.getElementById('form-container');
  }

  function getCurrentUserId() {
    try {
      const raw = localStorage.getItem('whitecoat_user');
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      const userId = parsed && parsed.user_id ? String(parsed.user_id) : '';
      return userId ? userId : null;
    } catch (e) {
      return null;
    }
  }

  async function getPatientsForAutofill() {
    const userId = getCurrentUserId();
    if (!userId) {
      return [];
    }

    if (cachedPatients && lastUserId === userId) {
      return cachedPatients;
    }

    const endpoint = '/index.php/api/doctor/patients?user_id=' + encodeURIComponent(userId);
    const response = await fetch(endpoint, { method: 'GET' });
    if (!response.ok) {
      return [];
    }

    const data = await response.json();
    const patients = Array.isArray(data) ? data : [];
    cachedPatients = patients;
    lastUserId = userId;
    return patients;
  }

  async function autofillMaintenanceByName() {
    const fullNameInput = document.getElementById('fullname');
    const maintenanceInput = document.getElementById('maintenance');
    if (!fullNameInput || !maintenanceInput) {
      return;
    }

    const name = String(fullNameInput.value || '').trim().toLowerCase();
    if (!name) {
      return;
    }

    try {
      const patients = await getPatientsForAutofill();
      const match = patients.find(function (item) {
        const patientName = String((item && item.patient_name) || '').trim().toLowerCase();
        return patientName === name;
      });

      if (match && typeof match.maintenance === 'string') {
        maintenanceInput.value = match.maintenance;
      }
    } catch (e) {
    }
  }

  function startMaintenanceAutofillWatcher() {
    if (window.__whitecoatMaintenanceAutofillWatcherStarted) {
      return;
    }
    window.__whitecoatMaintenanceAutofillWatcherStarted = true;

    window.setInterval(function () {
      const fullNameInput = document.getElementById('fullname');
      if (!fullNameInput) {
        return;
      }

      const currentName = String(fullNameInput.value || '').trim();
      if (!currentName || currentName === lastAutofillName) {
        return;
      }

      lastAutofillName = currentName;
      autofillMaintenanceByName();
    }, 250);
  }

  function getPatientTypeContainer(root) {
    if (!root) return null;
    const patientTypeSelect = root.querySelector('select#patient_type, select[name="patient_type"]');
    return patientTypeSelect ? patientTypeSelect.closest('div') : null;
  }

  function getScopeAttrs(element) {
    if (!element || !element.getAttributeNames) {
      return [];
    }
    return element
      .getAttributeNames()
      .filter(function (name) {
        return /^data-v-/.test(name);
      });
  }

  function applyScopeAttrs(element, attrs) {
    if (!element || !Array.isArray(attrs)) {
      return;
    }
    attrs.forEach(function (name) {
      element.setAttribute(name, '');
    });
  }

  function ensureField(anchor, id, labelText, placeholderText, required) {
    if (!anchor) return anchor;

    const existing = document.getElementById(id);
    if (existing) {
      const wrapper = existing.closest('[data-prescription-extra-field]');
      return wrapper || anchor;
    }

    const wrapper = document.createElement('div');
    wrapper.setAttribute('data-prescription-extra-field', id);

    const scopeAttrs = getScopeAttrs(anchor);
    applyScopeAttrs(wrapper, scopeAttrs);

    const label = document.createElement('label');
    label.setAttribute('for', id);
    label.className = 'mt-2';
    label.textContent = labelText;
    applyScopeAttrs(label, scopeAttrs);

    const input = document.createElement('input');
    input.id = id;
    input.name = id;
    input.type = 'text';
    input.placeholder = placeholderText;
    input.className = 'form-input';
    applyScopeAttrs(input, scopeAttrs);
    if (required) {
      input.required = true;
    }

    wrapper.appendChild(label);
    wrapper.appendChild(input);
    anchor.parentNode.insertBefore(wrapper, anchor.nextSibling);
    return wrapper;
  }

  function ensurePrescriptionFields() {
    const formRoot = getFormRoot();
    const patientTypeContainer = getPatientTypeContainer(formRoot);
    if (!patientTypeContainer) {
      return;
    }

    const maintenanceWrapper = ensureField(
      patientTypeContainer,
      'maintenance',
      'Maintenance (Optional):',
      'Maintenance (optional)',
      false
    );
    ensureField(
      maintenanceWrapper,
      'reason_for_referral',
      'Reason for Referral:',
      'Reason for referral',
      true
    );
  }

  function getFieldValue(id) {
    const element = document.getElementById(id);
    return element ? String(element.value || '').trim() : '';
  }

  function patchXhrPayload() {
    if (window.__whitecoatPrescriptionPatchedXhr) {
      return;
    }
    window.__whitecoatPrescriptionPatchedXhr = true;

    const originalOpen = XMLHttpRequest.prototype.open;
    const originalSend = XMLHttpRequest.prototype.send;

    XMLHttpRequest.prototype.open = function (method, url) {
      this.__whitecoatUrl = typeof url === 'string' ? url : '';
      return originalOpen.apply(this, arguments);
    };

    XMLHttpRequest.prototype.send = function (body) {
      try {
        const url = String(this.__whitecoatUrl || '');
        if (url.includes('/api/doctor/prescription/generate') && typeof body === 'string') {
          const parsed = JSON.parse(body);
          if (parsed && typeof parsed === 'object') {
            parsed.maintenance = getFieldValue('maintenance');
            parsed.reason_for_referral = getFieldValue('reason_for_referral');
            body = JSON.stringify(parsed);
          }
        }
      } catch (e) {
      }

      return originalSend.call(this, body);
    };
  }

  function guardCreatePrescriptionClick() {
    if (window.__whitecoatPrescriptionPatchedClick) {
      return;
    }
    window.__whitecoatPrescriptionPatchedClick = true;

    document.addEventListener(
      'click',
      function (event) {
        const target = event.target;
        if (!(target instanceof Element)) {
          return;
        }

        const button = target.closest('button, ion-button');
        if (!button) {
          return;
        }

        const text = String(button.textContent || '').trim().toLowerCase();
        if (!text.includes('create prescription')) {
          return;
        }

        const reason = getFieldValue('reason_for_referral');
        if (!reason) {
          event.preventDefault();
          event.stopPropagation();
          event.stopImmediatePropagation();
          alert('Reason for Referral is required.');
        }
      },
      true
    );
  }

  function isFilled(id) {
    const element = document.getElementById(id);
    if (!element) {
      return false;
    }
    return String(element.value || '').trim() !== '';
  }

  function hasValidMedicationFields() {
    const inputs = Array.from(document.querySelectorAll('#form-container .med-input'));
    if (inputs.length === 0) {
      return false;
    }

    return inputs.every(function (input) {
      return String((input && input.value) || '').trim() !== '';
    });
  }

  function isPrescriptionFormComplete() {
    return (
      isFilled('fullname') &&
      isFilled('age') &&
      isFilled('gender') &&
      isFilled('dateIssued') &&
      isFilled('address') &&
      isFilled('patient_type') &&
      isFilled('reason_for_referral') &&
      hasValidMedicationFields()
    );
  }

  function findCreatePrescriptionButton() {
    const candidates = Array.from(document.querySelectorAll('button, ion-button'));
    return (
      candidates.find(function (button) {
        const text = String(button.textContent || '').trim().toLowerCase();
        return text.includes('create prescription');
      }) || null
    );
  }

  function syncCreatePrescriptionButtonState() {
    const button = findCreatePrescriptionButton();
    if (!button) {
      return;
    }

    const shouldEnable = isPrescriptionFormComplete();
    const shouldDisable = !shouldEnable;

    button.disabled = shouldDisable;
    if (shouldDisable) {
      button.setAttribute('disabled', 'disabled');
    } else {
      button.removeAttribute('disabled');
    }
  }

  function startCreateButtonStateWatcher() {
    if (window.__whitecoatCreateButtonWatcherStarted) {
      return;
    }
    window.__whitecoatCreateButtonWatcherStarted = true;

    const scheduleSync = function () {
      window.setTimeout(syncCreatePrescriptionButtonState, 0);
    };

    document.addEventListener('input', scheduleSync, true);
    document.addEventListener('change', scheduleSync, true);
    document.addEventListener('click', scheduleSync, true);

    window.setInterval(syncCreatePrescriptionButtonState, 250);
  }

  function normalizeDateKey(value) {
    const raw = String(value || '').trim();
    if (!raw || raw === '—') {
      return '';
    }

    const isoMatch = raw.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
    if (isoMatch) {
      const year = isoMatch[1];
      const month = String(isoMatch[2]).padStart(2, '0');
      const day = String(isoMatch[3]).padStart(2, '0');
      return year + '-' + month + '-' + day;
    }

    const usMatch = raw.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    if (usMatch) {
      const month = String(usMatch[1]).padStart(2, '0');
      const day = String(usMatch[2]).padStart(2, '0');
      const year = usMatch[3];
      return year + '-' + month + '-' + day;
    }

    const parsed = new Date(raw);
    if (isNaN(parsed.getTime())) {
      return '';
    }

    const year = String(parsed.getFullYear());
    const month = String(parsed.getMonth() + 1).padStart(2, '0');
    const day = String(parsed.getDate()).padStart(2, '0');
    return year + '-' + month + '-' + day;
  }

  function getHistoryRows() {
    const userId = getCurrentUserId();
    if (!userId) {
      return Promise.resolve([]);
    }

    const isFresh =
      Array.isArray(cachedHistoryRows) &&
      lastHistoryUserId === userId &&
      Date.now() - lastHistoryFetchedAt < 20000;

    if (isFresh) {
      return Promise.resolve(cachedHistoryRows);
    }

    if (historyFetchInFlight && lastHistoryUserId === userId) {
      return historyFetchInFlight;
    }

    const endpoint = '/index.php/api/doctor/prescription/history?user_id=' + encodeURIComponent(userId);
    historyFetchInFlight = fetch(endpoint)
      .then(function (response) {
        if (!response.ok) {
          return [];
        }
        return response.json();
      })
      .then(function (rows) {
        const normalizedRows = Array.isArray(rows) ? rows : [];
        cachedHistoryRows = normalizedRows;
        lastHistoryUserId = userId;
        lastHistoryFetchedAt = Date.now();
        historyFetchInFlight = null;
        return normalizedRows;
      })
      .catch(function () {
        historyFetchInFlight = null;
        return [];
      });

    return historyFetchInFlight;
  }

  function getDetailValue(labelPrefix) {
    const detailRows = Array.from(document.querySelectorAll('.history-detail-modal .detail-section .detail-line'));
    const normalizedPrefix = String(labelPrefix || '').toLowerCase();
    const row = detailRows.find(function (item) {
      const text = String(item.textContent || '').trim().toLowerCase();
      return text.startsWith(normalizedPrefix);
    });
    if (!row) {
      return '';
    }
    return String(row.textContent || '').replace(new RegExp('^' + labelPrefix + '\\s*', 'i'), '').trim();
  }

  function enrichHistoryPatientInfo() {
    const docGrid = document.querySelector('.history-detail-modal .prescription-document .doc-section .doc-grid');
    if (!docGrid) {
      return;
    }

    Array.from(docGrid.querySelectorAll('.wc-history-extra-field')).forEach(function (node) {
      node.remove();
    });

    const issuedAtText = getDetailValue('Issued at:');
    const patientName = getDetailValue('Name:');

    if (!issuedAtText || issuedAtText === '—') {
      return;
    }

    const issuedAtKey = normalizeDateKey(issuedAtText);
    const patientNameKey = String(patientName || '').trim().toLowerCase();

    getHistoryRows()
      .then(function (rows) {
        if (!Array.isArray(rows)) {
          return;
        }

        const matchesPatient = function (row) {
          if (!patientNameKey) {
            return true;
          }
          const rowName = String((row && row.patient_name) || (row && row.name) || '').trim().toLowerCase();
          return rowName === patientNameKey;
        };

        const matchesDate = function (row) {
          if (!issuedAtKey) {
            return true;
          }
          const rowDate = normalizeDateKey((row && row.date_issued) || (row && row.created_at) || '');
          return rowDate === issuedAtKey;
        };

        const match =
          rows.find(function (row) {
            return matchesPatient(row) && matchesDate(row);
          }) ||
          rows.find(function (row) {
            return matchesDate(row);
          }) ||
          rows.find(function (row) {
            return matchesPatient(row);
          });

        if (!match) {
          return;
        }

        const maintenanceValue = match.maintenance ? String(match.maintenance).trim() : '';
        const reasonValue = match.reason_for_referral ? String(match.reason_for_referral).trim() : '';

        if (!maintenanceValue && !reasonValue) {
          return;
        }

        const createRow = function (labelText, valueText) {
          const row = document.createElement('div');
          row.className = 'doc-field full-width wc-history-extra-field';

          const label = document.createElement('span');
          label.className = 'label';
          label.textContent = labelText;

          row.appendChild(label);
          row.appendChild(document.createTextNode(' ' + (valueText || '—')));
          return row;
        };

        if (maintenanceValue) {
          docGrid.appendChild(createRow('Maintenance:', maintenanceValue));
        }
        if (reasonValue) {
          docGrid.appendChild(createRow('Reason for Referral:', reasonValue));
        }
      })
      .catch(function () {
      });
  }

  function startHistoryEnhancerWatcher() {
    if (window.__whitecoatHistoryEnhancerStarted) {
      return;
    }
    window.__whitecoatHistoryEnhancerStarted = true;

    window.setInterval(enrichHistoryPatientInfo, 500);
  }

  function init() {
    ensurePrescriptionFields();
    patchXhrPayload();
    guardCreatePrescriptionClick();
    startMaintenanceAutofillWatcher();
    startCreateButtonStateWatcher();
    startHistoryEnhancerWatcher();
    syncCreatePrescriptionButtonState();

    const scheduleEnsure = function () {
      window.setTimeout(function () {
        ensurePrescriptionFields();
        syncCreatePrescriptionButtonState();
      }, 0);
    };

    window.addEventListener('hashchange', scheduleEnsure);
    window.addEventListener('popstate', scheduleEnsure);
    document.addEventListener('click', scheduleEnsure, true);

    let tries = 0;
    const timer = window.setInterval(function () {
      ensurePrescriptionFields();
      syncCreatePrescriptionButtonState();
      tries += 1;
      if (document.getElementById('maintenance') && document.getElementById('reason_for_referral')) {
        autofillMaintenanceByName();
        window.clearInterval(timer);
      } else if (tries >= 30) {
        window.clearInterval(timer);
      }
    }, 500);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
