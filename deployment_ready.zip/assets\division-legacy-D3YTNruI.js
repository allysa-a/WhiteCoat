System.register([],function(e,t){"use strict";return{execute:function(){e("_","/deployment/assets/division-CWqrCBC8.png")}}});
